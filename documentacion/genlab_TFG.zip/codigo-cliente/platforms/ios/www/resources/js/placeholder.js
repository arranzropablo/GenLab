$(".form-username").val("Username...");
$(".form-password").val("Password...");