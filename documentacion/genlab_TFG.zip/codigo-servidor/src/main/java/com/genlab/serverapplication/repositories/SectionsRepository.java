package com.genlab.serverapplication.repositories;

import org.springframework.data.repository.CrudRepository;

import com.genlab.serverapplication.models.Sections;

public interface SectionsRepository extends CrudRepository<Sections, Integer>{

}
