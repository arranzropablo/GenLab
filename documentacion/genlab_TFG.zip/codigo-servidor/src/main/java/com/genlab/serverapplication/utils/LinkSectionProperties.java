package com.genlab.serverapplication.utils;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LinkSectionProperties {
	
	private String link;
	private String title;
	
}
